***********
projections
***********


:mod:`matplotlib.projections`
=============================

.. automodule:: matplotlib.projections
   :members:
   :show-inheritance:


:mod:`matplotlib.projections.polar`
===================================

.. automodule:: matplotlib.projections.polar
   :members:
   :show-inheritance:
