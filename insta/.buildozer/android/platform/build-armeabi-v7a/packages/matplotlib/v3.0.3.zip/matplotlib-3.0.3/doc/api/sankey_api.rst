******
sankey
******


:mod:`matplotlib.sankey`
========================

.. automodule:: matplotlib.sankey
   :members:
   :undoc-members:
   :show-inheritance:
