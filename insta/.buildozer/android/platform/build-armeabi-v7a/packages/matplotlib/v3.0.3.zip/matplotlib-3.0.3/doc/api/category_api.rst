***********************
``matplotlib.category``
***********************

.. automodule:: matplotlib.category
   :members:
   :undoc-members:
   :show-inheritance:
